package es.uniovi.eii.mainantojitos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import es.uniovi.eii.mainantojitos.modelo.Restaurante;
import es.uniovi.eii.mainantojitos.ui.CartaFragment;
import es.uniovi.eii.mainantojitos.ui.InfoFragment2;

public class ShowRestaurante extends AppCompatActivity {

    private Restaurante restaurante;
    ImageView imagenRestaurante;
    TextView categoria;
    TextView nombre;
    TextView telefono;
    TextView descripcion;
    ImageView carta;
    CollapsingToolbarLayout toolBarLayout;

    InfoFragment2 firstFragment = new InfoFragment2();
    CartaFragment secondFragment = new CartaFragment();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_restaurante);

        //Recepción datos como activity secundaria
        Intent intentRes= getIntent();
        restaurante = intentRes.getParcelableExtra(PantallaPrincipal.RESTAURANTE_SELECCIONADO);


        // Gestión barra de la app
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_detrasdefoto);
        //setSupportActionBar(toolbar);
        toolBarLayout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        toolBarLayout.setTitle(getTitle());

        //imagenRestaurante = findViewById(fotele);

        // Gestión de los controles que contienen los datos de restauranmte
//        categoria= (TextView)findViewById(R.id.categoria_res);
        telefono= (TextView)findViewById(R.id.textViewTelefono);
        nombre= (TextView)findViewById(R.id.textViewNombreRestaurante);
        descripcion = (TextView) findViewById(R.id.textViewDescripcion);
        carta = (ImageView) findViewById(R.id.imageView);
        int fotele = R.id.imagen_restaurante;
        Log.i("Foto","Foto: " + fotele);
        imagenRestaurante= (ImageView)findViewById(fotele);

        //categoria= (TextView) findViewById(R.id.categoria_res);

        //Gestion de la botonera
        BottomNavigationView navView = findViewById(R.id.nav_view_botonera);
//        //Le añado un listener
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        loadFragment(firstFragment);

        //if (restaurante !=null) //apertura en modo consulta
            //mostrarDatos(restaurante);
    }

    private void mostrarDatos(Restaurante restaurante) {
        if (!restaurante.getNombre().isEmpty()) { //apertura en modo consulta
            //Actualizar componentes con valores de la pelicula específica
            toolBarLayout.setTitle(restaurante.getNombre());
            // Imagen de fondo
//            Picasso.get()
//                    .load(restaurante.getDrawImg()).into(imagenRestaurante);
            //imagenRestaurante.setImageResource(R.drawable.casa_marcial);  FALLO AQUI AQUI QUE LO CREA NULL
            //categoria.setText(restaurante.getCategoria().getNombre());
            nombre.setText(restaurante.getNombre());
            telefono.setText(restaurante.getTelefono());
            descripcion.setText(restaurante.getDescripcion());
//            carta.setImageResource(restaurante.getCarta());    ESTO CAMBIAR POR FOTO

        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            if (restaurante != null) {

                switch (item.getItemId()) {
                    case R.id.navigation_info:
                        //Creamos el framento de información
//                        InfoFragment info = new InfoFragment();
//                        Bundle args = new Bundle();
//                        args.putString(InfoFragment.NOMBRE, restaurante.getNombre());
//                        args.putString(InfoFragment.TELEFONO, restaurante.getTelefono());
//                        args.putString(InfoFragment.IMAGEN, restaurante.getUrlFoto());
//                        info.setArguments(args);
//                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, info).commit();

                        loadFragment(firstFragment);


                        return true;

                    case R.id.navigation_carta:
//                        CartaFragment cartaFragment = new CartaFragment();
//                        Bundle args1 = new Bundle();
                        //Enviamos el id del restaurante para buscar SU CARTA en la base de datos.
//                        args1.putInt("id_restaurante", restaurante.getId() );
//                        cartaFragment.setArguments(args1);
//                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, cartaFragment).commit();
                        loadFragment(secondFragment);
                        return true;

                    default:
                        throw new IllegalStateException("Unexpected value: " + item.getItemId());
                }

            }
            return false;
        }
    };

    public void loadFragment(Fragment fragment){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }
}