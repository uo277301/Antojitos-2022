package es.uniovi.eii.mainantojitos.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import es.uniovi.eii.mainantojitos.R;

public class CartaFragment extends Fragment {
    public static final String PRODUCTO="producto";
    public static final String NOMBRE="Nombre";

    //Lista para el recycler
    List<String> carta = new ArrayList<String>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_carta, container, false);
        //Y tomamos el RecyclerView que viene en dicho fragment definidio por xml
        final RecyclerView recycleCarta = (RecyclerView) root.findViewById(R.id.reciclerViewCarta);


        //Instanciamos el LayoutManager correspondiente
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(root.getContext());
        recycleCarta.setLayoutManager(layoutManager);

        recycleCarta.setHasFixedSize(true);

//        Bundle args=getArguments();
//        int id_restaurante = args.getInt("id_restaurante");
//
//        //Creamos un películas data source para llamar al método que por SQL nos localizará el reparto
//        ActorsDataSource actoresDataSource = new ActorsDataSource(root.getContext());
//        actoresDataSource.open();
//        listaActores = actoresDataSource.actoresParticipantes(id_pelicula);
//        actoresDataSource.close();
//
//        // Definición de onclik del actor
//        ListaActoresAdapter laAdapter = new ListaActoresAdapter(listaActores,
//                new ListaActoresAdapter.OnItemClickListener() {
//                    @Override
//                    public void onItemClick(Actor actor) {
//                        //Si pulsamos sobre un actor nos llevará a su ficha en Imdb
//                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(actor.getUrlImdb())));
//                    }
//                });
//
//        recycleActors.setAdapter(laAdapter);
//        return root;
        return root;
    }

}
